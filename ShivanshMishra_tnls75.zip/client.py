
import socket
import threading
import os
import sys

# Create a directory for the user to store downloaded files
def create_user_directory(username):
    os.makedirs(username, exist_ok=True)

# Receive messages from the server and handle file downloads4
def receive_messages(client_socket, stop_event, username):
    while not stop_event.is_set():
        try:
            message = client_socket.recv(1024).decode('utf-8', errors='ignore')
            if "Start of file" in message:
                filename = message.split()[3]
                download_file(client_socket, filename, username)
                print(f"\n{username}> ", end='', flush=True)
            else:
                print(message, end=f'\n{username}> ', flush=True)
        except ConnectionAbortedError:
            break
        except Exception as e:
            print(f"Error receiving message: {e}")

# Download a file from the server and save it in the user's directory.
def download_file(client_socket, filename, username):
    filepath = os.path.join(username, f"downloaded_{filename}")
    try:
        downloaded_data = b''
        while True:
            chunk = client_socket.recv(1024)
            if "End of file" in chunk.decode('utf-8', errors='ignore'):
                break
            downloaded_data += chunk

        with open(filepath, 'wb') as f:
            f.write(downloaded_data)
        print(f"File '{filename}' downloaded successfully to {filepath}!")
    except Exception as e:
        print(f"Error downloading file: {e}")

# Send messages to the server, including handling special commands like 'exit' and 'help'.
def send_messages(client_socket, stop_event, username):
    while not stop_event.is_set():
        try:
            message = input(f"{username}> ")
            if message.lower() == 'exit':
                stop_event.set()
                client_socket.sendall("exit".encode('utf-8'))
                client_socket.close()
                print("Exiting chat...")
                break
            elif message.lower() == 'help':
                print_help_commands()
            else:
                client_socket.sendall(message.encode('utf-8'))

                if message.lower().startswith('download'):
                    filename = message.split()[1]
                    print(f"Downloading {filename}...")

        except IndexError:
            print("Invalid input. Please provide a filename or type 'help' for assistance.")
        except Exception as e:
            print(f"Error sending message: {e}")

# Print help commands available for the user.
def print_help_commands():
    print("\nAvailable commands:")
    print("  @username <message> - Send a private message to a user")
    print("  broadcast <message> - Send a message to all users")
    print("  listfiles - List all available files for download")
    print("  download <filename> - Download a file")
    print("  exit - Exit the chat\n")

def main():
    if len(sys.argv) != 4:
        print("Usage: python client.py [username] [hostname] [port]")
        sys.exit(1)

    username = sys.argv[1]
    host = sys.argv[2]
    port = int(sys.argv[3])

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))

    create_user_directory(username)
    client_socket.sendall(username.encode('utf-8'))

    welcome_message = client_socket.recv(1024).decode('utf-8')
    print(welcome_message)

    stop_event = threading.Event()

    send_thread = threading.Thread(target=send_messages, args=(client_socket, stop_event, username))
    receive_thread = threading.Thread(target=receive_messages, args=(client_socket, stop_event, username))

    send_thread.start()
    receive_thread.start()

    send_thread.join()
    receive_thread.join()

# Execute the main function when the script is run.
if __name__ == "__main__":
    main()

