Following is the step-by-step instruction set on how to work with the peer-to-peer messenger.

Starting the server
1) Copy server.py to a folder.
2) Start server.py by typing 'server.py [port number]' for example 'server.py 12000'
3) Once server is listening on specified port number, 'Server is listening on 127.0.0.1:12000', server is ready and listening

Starting the client
1) Copy client.py to a folder.
2) Start client.py by typing 'client.py [Username] [host number] [port number]
3) Once client has joined the server, 'Welcome [Username]', is displayed
4)Type "help" for all the commands avaliable in client.
for example if user Lee types help, below will be the output- 
Lee> help

Available commands:
  @username <message> - Send a private message to a user
  broadcast <message> - Send a message to all users
  listfiles - List all available files for download
  download <filename> - Download a file
  exit - Exit the chat

5) Test all the functionalities given in the assignment
