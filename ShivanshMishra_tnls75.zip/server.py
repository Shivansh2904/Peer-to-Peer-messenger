


import socket
import threading
import logging
import signal
import sys
from concurrent.futures import ThreadPoolExecutor
import os


clients = {}
server_running = threading.Event()
executor = ThreadPoolExecutor(max_workers=20)
download_path = os.path.join(os.getcwd(), "downloads")


logging.basicConfig(filename='server.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
console = logging.StreamHandler()
console.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
console.setFormatter(formatter)
logging.getLogger('').addHandler(console)

# Handle a client connection by receiving and processing messages
def handle_client(client_socket, addr):
    try:
        client_username = client_socket.recv(1024).decode('utf-8')
        clients[client_username] = client_socket

        # Notify all clients about the new connection.
        if client_username not in clients:
            send_to_all_clients(f"{client_username} joined the chat.\n")
        
        logging.info(f"New connection: {client_username} joined from {addr}")
        # Send a welcome message to the client
        welcome_msg = "type \"help\" to view a list of commands that can be used"
        client_socket.sendall(welcome_msg.encode('utf-8'))

        while True:
            message = client_socket.recv(1024).decode('utf-8')
            if not message:
                break
            process_client_message(client_username, message)
    except Exception as e:
        logging.error(f"Error with client {client_username}: {e}")
    finally:
        handle_disconnect(client_username)

# Process different types of client messages based on commands.
def process_client_message(client_username, message):
    parts = message.split(' ', 1)
    command = parts[0].lower()

    if command.startswith('@') and len(parts) > 1:
        recipient, private_message = command[1:], parts[1]
        send_private_message(client_username, recipient, private_message)
        logging.info(f"Private message from {client_username} to {recipient}")

    elif command == 'broadcast' and len(parts) > 1:
        broadcast_message = parts[1]
        broadcast(client_username, broadcast_message)
        logging.info(f"Broadcast message from {client_username}")

    elif command == 'listfiles':
        send_file_list(client_username)
        logging.info(f"File list requested by {client_username}")

    elif command.startswith('download') and len(parts) > 1:
        filename = parts[1]
        create_user_directory(client_username)
        send_file(client_username, filename)
        logging.info(f"File {filename} requested for download by {client_username}")

    else:
        msg = "Invalid command. Type '@username message' for private message or 'broadcast message' for broadcast."
        clients[client_username].sendall(msg.encode('utf-8'))

# Send a message to all connected clients.
def send_to_all_clients(message):
    for username, client_socket in clients.items():
        try:
            client_socket.sendall(message.encode('utf-8'))
        except Exception as e:
            logging.error(f"Error sending message to {username}: {e}")

# Handle client disconnect, logging the event and notifying other clients.
def handle_disconnect(client_username):
    if client_username in clients:
        logging.info(f"{client_username} left the chat.")
        clients[client_username].close()
        del clients[client_username]
        send_to_all_clients(f"{client_username} has left the chat.\n")

def send_private_message(sender, recipient, message):
    if recipient in clients:
        private_msg = f"{sender} (private): {message}"
        clients[recipient].sendall(private_msg.encode('utf-8'))
    else:
        sender_socket = clients[sender]
        sender_socket.sendall(f"User '{recipient}' not found or offline.".encode('utf-8'))

def broadcast(sender, message):
    for username, client_socket in clients.items():
        if username != sender:
            try:
                broadcast_msg = f"{sender}: {message}"
                client_socket.sendall(broadcast_msg.encode('utf-8'))
            except Exception as e:
                logging.error(f"Error broadcasting to {username}: {e}")

def send_file_list(client_username):
    try:
        file_list = os.listdir(download_path)
        message = "Available files:\n" + "\n".join(file_list)
        clients[client_username].sendall(message.encode('utf-8'))
    except Exception as e:
        clients[client_username].sendall(f"Error listing files: {e}".encode('utf-8'))

def send_file(client_username, filename):
    file_path = os.path.join(download_path, filename)
    if not os.path.exists(file_path):
        clients[client_username].sendall(f"File '{filename}' not found.".encode('utf-8'))
        return

    try:
        with open(file_path, 'rb') as f:
            clients[client_username].sendall(f"Start of file {filename}".encode('utf-8'))
            while True:
                bytes_read = f.read(1024)
                if not bytes_read:
                    break
                clients[client_username].sendall(bytes_read)
            clients[client_username].sendall(f"End of file {filename}".encode('utf-8'))
    except Exception as e:
        clients[client_username].sendall(f"Error sending file {filename}: {e}".encode('utf-8'))

def create_user_directory(username):
    os.makedirs(os.path.join(download_path, username), exist_ok=True)

def start_server(host, port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((host, port))
    server.listen(5)
    logging.info(f"Server is listening on {host}:{port}")

    # Set a timeout for the server socket to check for server shutdown periodically.
    server.settimeout(1)

    while not server_running.is_set():
        try:
            client_socket, addr = server.accept()
            executor.submit(handle_client, client_socket, addr)
        except socket.timeout:
            continue
        except Exception as e:
            logging.error(f"Server error: {e}")

    server.close()

# Handle the interruption signal (Ctrl+C) to gracefully stop the server.
def signal_handler(sig, frame):
    logging.info("Received signal to stop the server.")
    server_running.set()

signal.signal(signal.SIGINT, signal_handler)

# Main entry point for the server script.
if __name__ == "__main__":

    if not os.path.exists(download_path):
        os.makedirs(download_path)


    if len(sys.argv) > 1:
        port = int(sys.argv[1])
    else:
        print("Usage: python server.py [port]")
        sys.exit(1)

    host = '127.0.0.1'

    server_thread = threading.Thread(target=start_server, args=(host, port))
    server_thread.start()

    try:
        while not server_running.is_set():
            pass
    except KeyboardInterrupt:
        server_running.set()
        server_thread.join()
        executor.shutdown(wait=False)
        sys.exit(0)

